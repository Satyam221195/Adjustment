clear all
clc
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
fprintf('---------------Term Paper ACG-II ---------------------------\n');
fprintf('-------Satyam Agnihotri----- Roll No. 231030406---------------\n');
fprintf('-------------------------------------------------------------\n');
%% Q1 A. Observation Equation Non-Linear (Minimum Constraints) 

% Given

c = 562.100 ; % in meter
a = 623.800 ;% in meter
b = 746.838 ;% in meter
A = (pi/180)*(dms2degrees(54,44,50)); % in radians
B = (pi/180)*(dms2degrees(77,52,10)); % in radians
C = (pi/180)*(dms2degrees(47,22,55)); % in radians

Lb = [c;a;b;A;B;C];
disp('Onservation Matrix Lb:');
disp(Lb);
fprintf('-------------------------------------------------------------\n');

% Error - covariances we have

e1 =  5/1000 ; % in mm
e2 =  5/1000 ;% in mm
e3 =  5/1000 ;% in mm
e4 = (pi/180)*dms2degrees(0,0,5);
e5 = (pi/180)*dms2degrees(0,0,5);
e6 = (pi/180)*dms2degrees(0,0,5);


 % sigma lblb
E_lb = diag([e1^2,e2^2,e3^2,e4^2,e5^2,e6^2]);
apriori = 1; % sigma_0 square
P = apriori * inv(E_lb);

disp(" Weight Matirx P:");
%disp(P);
fprintf('-------------------------------------------------------------\n');


% Number of observations
n = 6;
disp('Number of observation:');
disp(n);
% No. of Paramters
u = 6;
disp('Number of Parameters:');
disp(u);
% Degree f freedom
r = 0;
disp('Degree of Freedom:');
disp(r);
fprintf('-------------------------------------------------------------\n');

disp('Since Degree of Freedom is 0 so we apply constarints to solve them:');
fprintf('-------------------------------------------------------------\n');

% intial coordinates

ax_i = 1000.0 ; % in meters
ay_i = 1000.0 ; % in meters
bx_i = 1386.9 ; % in meters
by_i = 1407.3 ; % in meters
cx_i = 1739.1 ; % in meters
cy_i =  892.8 ; % in meters


X0 = [ax_i; ay_i; bx_i; by_i; cx_i; cy_i];
fprintf('Initial Coordinates Matrix X0 (Up to 3 decimal places):\n');
fprintf('%.3f\n', X0);

fprintf('-------------------------------------------------------------\n');

for i= 1:100

% Initial observations

syms ax ay bx by cx cy

f1 = sqrt( (ax - bx)^2 + (ay - by)^2 );
f2 = sqrt( (bx - cx)^2 + (by - cy)^2 );
f3 = sqrt( (ax - cx)^2 + (ay - cy)^2 );
f4 = (pi + atan((cx - ax) / (cy - ay))) - (atan((bx - ax) / (by - ay)));
f5 = (pi + atan((ax - bx) / (ay - by))) - (pi+(atan((cx - bx) / (cy - by))));
f6 = ((2 * pi) + (atan((bx - cx) / (by - cy)))) - ((2 * pi) +(atan((ax - cx) / (ay - cy))));


equ = [f1,f2,f3,f4,f5,f6]';
L0 = double(subs(equ,[ax,ay,bx,by,cx,cy],X0'));
disp('Initial Onservation Matrix L0:');
disp(L0);

fprintf('-------------------------------------------------------------\n');

% L Matrix

L = Lb -L0;
disp('Matrix L = Lb - L0:');
%disp(L);
fprintf('-------------------------------------------------------------\n');
% Preparing Design matrix A

parameter_1 = [ax,ay,bx,by,cx,cy];
equations = [f1,f2,f3,f4,f5,f6]';

a = jacobian(equations, [ax,ay,bx,by,cx,cy]);
A=double(subs(a,[ax,ay,bx,by,cx,cy],X0'));

% Display the Jacobian matrix
disp("A: Design Matrix");
%disp(A);

fprintf('-------------------------------------------------------------\n');

N = A'*P*A ;


U = A'*P*L;
disp("N and U is computed:n")
fprintf('-------------------------------------------------------------\n');

disp("I: Minimum Constraints\n");
disp("2 coordinates Xa, Ya is fixed and Azimuth (Alpha) is fixed");

fprintf('-------------------------------------------------------------\n');

cxa = 1000;
cya = 1000;
Alpha = (pi/180)*(dms2degrees(43,30,00));

disp("Constarints we have");
fprintf('-------------------------------------------------------------\n');

disp("Number of costarints or Number of conditions against parameters:");
s = 4;
disp("S")
disp(s)
fprintf('-------------------------------------------------------------\n');

% Compute coefficient matrix C
syms ax ay bx by cx cy
% ax = cxa;
% ay = cxb;
% bx = 1386.9;
% by = 1407.3;
f_c1 = ax;
f_c2 = ay;
f_c3 = atan((bx - ax) / (by - ay));


parameter_1 = [ax,ay,bx,by,cx,cy];
equations_c = [f_c1,f_c2,f_c3];

c = jacobian(equations_c, [ax,ay,bx,by,cx,cy]);
C = double(subs(c,[ax,ay,bx,by,cx,cy],[X0(1),X0(2),X0(3),X0(4),X0(5),X0(6)]));
% Display the Jacobian matrix
disp("C: Design Matrix of constraints");

fprintf('-------------------------------------------------------------\n');

% Miscloure vectoe W_c

W_c = [cxa-ax;cya-ay;atan((bx - ax) / (by - ay))-Alpha];

W_c = double(subs(W_c,[ax,ay,bx,by,cx,cy],[X0(1),X0(2),X0(3),X0(4),X0(5),X0(6)]));
disp("W_c: Misclosure vector");

fprintf('-------------------------------------------------------------\n');
N = N + C'*C;
N_inv = inv(N);
% Compute K_c

K_c = -inv((C*N_inv*C'))*(C*N_inv*U + W_c);

disp("K_c:");

fprintf('-------------------------------------------------------------\n');

% Compute delta X from inverse of quasi normal equation 

delta_X = (N_inv*U + N_inv*C'*K_c);

fprintf('-------------------------------------------------------------\n');

% Update approximate parameter vector 

Xa = X0 + delta_X;

fprintf('-------------------------------------------------------------\n');

% Residual V

V_linear = A * delta_X - L;
fprintf('-------------------------------------------------------------\n');

% VTPV linear

VTPV_linear = V_linear'*P*V_linear;
fprintf('-------------------------------------------------------------\n');

fprintf('-------------------------------------------------------------\n');

% Evaluate mathematical model F(X_a) = La

La = [sqrt( (Xa(1) - Xa(3))^2 + (Xa(2) - Xa(4))^2 );
    sqrt( (Xa(3) - Xa(5))^2 + (Xa(4) - Xa(6))^2 );
    sqrt( (Xa(1) - Xa(5))^2 + (Xa(2) - Xa(6))^2 );
    (pi + atan((Xa(5) - Xa(1)) / (Xa(6) - Xa(2)))) - (atan((Xa(3) - Xa(1)) / (Xa(4) - Xa(2))));
    (pi + atan((Xa(1) - Xa(3)) / (Xa(2) - Xa(4)))) - (pi+(atan((Xa(5) - Xa(3)) / (Xa(6) - Xa(4)))));
    ((2 * pi) + (atan((Xa(3) - Xa(5))/ (Xa(4) - Xa(6))))) - ((2 * pi) +(atan((Xa(1) - Xa(5)) / (Xa(2) - Xa(6)))))];

fprintf('-------------------------------------------------------------\n');
% Compute VTPV non linear

V_nonlinear = La - Lb;

% Computing  VTPV nonlinear
VTPV_nonlinear =  V_nonlinear'*P*V_nonlinear;
tolerance = 10^-8;

fprintf('--------------------------------------------------------------\n');



disp('Iteration no')
disp(i)
fprintf('--------------------------------------------------------------\n');
%convergence based on |VTPV_nonlinear - VTPV_linear| < tolerance
   if abs(VTPV_nonlinear - VTPV_linear) <tolerance;
               % A posteriori varience
        sigma_aposteiori= VTPV_linear/(n+s-u) ;
        disp('A posteriori varience')
        disp(sigma_aposteiori)

        break
        else
        disp('Convergence criteria reached')
        fprintf('\n')
          %  adjusted parameters become approximate parameters
         X0 = Xa;
        % adjusted observation become approximate observations
         L0 = La




    end
end

fprintf('--------------------------------------------------------------\n');

fprintf('Final Coordinates Matrix Xa (Up to 3 decimal places):\n');
fprintf('%.3f\n', Xa);

fprintf('--------------------------------------------------------------\n');
fprintf('Adjusted Observation La (Up to 4 decimal places):\n');
fprintf('%.4f\n', La);
fprintf('--------------------------------------------------------------\n');
La1 = La(1);
La2 = La(2);
La3 = La(3);
La4 = deg2dms((180/pi)*La(4));
La5 = deg2dms((180/pi)*La(5));
La6 = deg2dms((180/pi)*La(6));


disp("Adjusted Observation")
disp(La1);
disp(La2);
disp(La3);
disp(La4);
disp(La5);
disp(La6);
fprintf('--------------------------------------------------------------\n');
disp("Residual Vector V:");
fprintf('%.12f\n',V_linear);
fprintf('--------------------------------------------------------------\n');
disp("Residual")
V01 = 1000*V_linear(1);
V02 = 1000*V_linear(2);
V03 = 1000*V_linear(3);
V04 = deg2dms((180/pi)*V_linear(4));
V05 = deg2dms((180/pi)*V_linear(5));
V06 = deg2dms((180/pi)*V_linear(6));

disp(V01);
disp(V02);
disp(V03);
disp(V04);
disp(V05);
disp(V06);
fprintf('--------------------------------------------------------------\n');
2
 % Various Checks

  fprintf('------------------------Checks----------------------------\n');

% Check 1 for A'PV = 0
V = V_linear;
ATPV= A'*P*V;

if ATPV < 10^-3
    fprintf('Then ATPV is 0 and check successful\n')
else 
    fprintf('Unsuccessful: ATPV is not zero\n')
end

fprintf('--------------------------------------------------------------\n');

% Check 2 Calculating V'PV by three methods
fprintf("\nCalculating V'PV by three methods:\n");
fprintf("V'PV = ")
VTPV= V'*P*V;
disp(double(VTPV));

fprintf('--------------------------------------------------------------\n');

fprintf("-V'PLb = ")
VTPL=-V'*P*L;
disp(double(VTPL));

fprintf('--------------------------------------------------------------\n');

fprintf("-Lb'PV = ");
LTPV=-L'*P*V;
disp(double(LTPV));

fprintf('--------------------------------------------------------------\n\n\n');

% Stochastic Part 
disp('Stocastic Part')

 fprintf('--------------------------------------------------------------\n');

 % Computation of weighted coefficient matrix for observed Quantities
 Q_Lb = inv(P);
 disp('Weighted coefficient matrix for Observed Quantities (Q_Lb) (6 x 6)-');
 disp(Q_Lb);

fprintf('--------------------------------------------------------------\n');

 %Computation of weighted coefficient matrix for observed Quantities
 Q_Xa = inv(N);
 disp('Weighted Coefficient matrix for Adjusted Parameters (Q_Xa) (6 x 6)');
 disp(Q_Xa);

 fprintf('--------------------------------------------------------------\n');

 % Computation of weighted coefficient matrix for adjusted observation
Q_La = A*inv(N)*A';
disp('Weighted Coefficient matrix for Adjusted Observation (Q_La)(6 x 6)');
 disp(Q_La);

 fprintf('--------------------------------------------------------------\n');

 % Computation of weighted coefficient matrix for residual
Q_V = Q_Lb - Q_La;
disp('Weighted Coefficient matrix for Residual (Q_V) (6 x 6)');
 disp(Q_V);

 fprintf('--------------------------------------------------------------\n');
apost = sigma_aposteiori;
 % Covariance matrix for Observed Values
 sigma_Lb = apost*Q_Lb;
 disp('Covariance Matrix of observation Q_Lb (6 x 6)-');
 disp(sigma_Lb);

 fprintf('--------------------------------------------------------------\n');

 % A posteriori covariance matrix for parameters
 sigma_Xa = apost*Q_Xa;
 disp('Covariance Matrix of Parameters Q_Xa(6 x 6)-');
 disp(sigma_Xa);

fprintf('--------------------------------------------------------------\n');

 % A posteriori covariance matrix for adjusted observation
 sigma_La = apost*Q_La;
 disp('Covariance Matrix of Adjusted Values Q_La (6 x 6)-');
 disp(sigma_La);

fprintf('--------------------------------------------------------------\n');

 % A poesteriori covariance matrix for residuals
 sigma_V = apost*Q_V;
 disp('Covariance Matrix of Residual Q_v (6 x 6) ');
 disp(sigma_V);

 fprintf('--------------------------------------------------------------\n');

 % Post processing

% Pope's tau Test 

% tinv of machine learning toolbox used with 0.95 as confidence interval
% and r as degree of fredom

% Calculate the t-value for the 0.95 confidence interval and given degrees of freedom
t_v1 = tinv(0.95, r);

% Calculate the threshold for the test statistic
T_v = t_v1 * sqrt(r) / sqrt(r - 1 + t_v1^2);

% Assuming V is a vector, Test statistics
V = V;
for i = 1:length(V)
    % Assuming sigma_0_sqr is a predefined variable
    T_i = V(i) / apost * sqrt(Q_V(i, i));
    
    % Perform the test
    if T_i > T_v
        disp(['Hypothesis rejected for element ' num2str(i)]);
    else
        disp(['Hypothesis accepted for element ' num2str(i)]);
    end
end

% errror elipse for local coordinate
s_0 = sqrt(apost);
a_local = s_0*sqrt(Q_Xa(1,1));
b_local = s_0*sqrt(Q_Xa(2,2));


% errror elipse for global coordinate

% for rotation angle

t = (1/2)*atan(Q_Xa(1,2)/(Q_Xa(2,2)-Q_Xa(1,1)));
R = [sin(t), cos(t); -cos(t), sin(t)];
Q = [Q_Xa(1,1),Q_Xa(1,2);
     Q_Xa(2,1),Q_Xa(2,2)];
Q_zz = R*Q*R';
a_global =  s_0*sqrt(Q_zz(1,1));
b_global =  s_0*sqrt(Q_zz(2,2));


% Plot Error ellipse

covariance_matrix = Q_Xa;  % Covariance matrix

% Number of points on the ellipse
num_points = 100;

% Generate points on the unit circle
theta = linspace(0, 2 * pi, num_points);
points_on_circle1= [a_global*cos(theta); b_global*sin(theta)];
points_on_circle2 = [a_local*cos(theta); b_local*sin(theta)];

% Plot the ellipse
figure(1);
plot(points_on_circle1(1, :), points_on_circle1(2, :), '-');
hold on;
plot(points_on_circle2(1, :), points_on_circle2(2, :), '-');
title('Error Ellipse Point A I: Minimum Constraints');
xlabel('X-axis');
ylabel('Y-axis');
hold off;
grid on;
axis equal;
fprintf('------------------------------------------------------------------\n');

% errror elipse for local coordinate
s_0 = sqrt(apost);
a_local = s_0*sqrt(Q_Xa(3,3));
b_local = s_0*sqrt(Q_Xa(4,4));


% errror elipse for global coordinate

% for rotation angle

t = (1/2)*atan(Q_Xa(3,4)/(Q_Xa(4,4)-Q_Xa(3,3)));
R = [sin(t), cos(t); -cos(t), sin(t)];
Q = [Q_Xa(3,3),Q_Xa(3,4);
     Q_Xa(4,3),Q_Xa(4,4)];
Q_zz = R*Q*R';
a_global =  s_0*sqrt(Q_zz(1,1));
b_global =  s_0*sqrt(Q_zz(2,2));


% Plot Error ellipse

covariance_matrix = Q_Xa;  % Covariance matrix

% Number of points on the ellipse
num_points = 100;

% Generate points on the unit circle
theta = linspace(0, 2 * pi, num_points);
points_on_circle1= [a_global*cos(theta); b_global*sin(theta)];
points_on_circle2 = [a_local*cos(theta); b_local*sin(theta)];

% Plot the ellipse
figure(2);
plot(points_on_circle1(1, :), points_on_circle1(2, :), '-');
hold on;
plot(points_on_circle2(1, :), points_on_circle2(2, :), '-');
title('Error Ellipse Point B I: Minimum Constraints');
xlabel('X-axis');
ylabel('Y-axis');
hold off;
grid on;
axis equal;
fprintf('------------------------------------------------------------------\n');

% errror elipse for local coordinate
s_0 = sqrt(apost);
a_local = s_0*sqrt(Q_Xa(5,5));
b_local = s_0*sqrt(Q_Xa(6,6));


% errror elipse for global coordinate

% for rotation angle

t = (1/2)*atan(Q_Xa(5,6)/(Q_Xa(6,6)-Q_Xa(5,5)));
R = [sin(t), cos(t); -cos(t), sin(t)];
Q = [Q_Xa(5,5),Q_Xa(5,6);
     Q_Xa(5,6),Q_Xa(6,6)];
Q_zz = R*Q*R';
a_global =  s_0*sqrt(Q_zz(1,1));
b_global =  s_0*sqrt(Q_zz(2,2));


% Plot Error ellipse

covariance_matrix = Q_Xa;  % Covariance matrix

% Number of points on the ellipse
num_points = 100;

% Generate points on the unit circle
theta = linspace(0, 2 * pi, num_points);
points_on_circle1= [a_global*cos(theta); b_global*sin(theta)];
points_on_circle2 = [a_local*cos(theta); b_local*sin(theta)];

% Plot the ellipse
figure(3);
plot(points_on_circle1(1, :), points_on_circle1(2, :), '-');
hold on;
plot(points_on_circle2(1, :), points_on_circle2(2, :), '-');
title('Error Ellipse Point C I: Minimum Constraints ');
xlabel('X-axis');
ylabel('Y-axis');
hold off;
grid on;
axis equal;
fprintf('------------------------------------------------------------------\n');

fprintf("Chi-Square Test: \n");

alph = 0.05;  % Significance level
DOF = s;
% Finding the critical value for a chi-square distribution
critical_value1 = chi2inv((alph/2),DOF);
critical_value2 = chi2inv((1 - (alph/2)),DOF);

Chi= VTPV/apost;

if Chi > critical_value1 && Chi < critical_value2
        fprintf("Chi-Square test succefully done \n");
    else
        fprintf("Chi-Square test fails \n");
end


%% Q1 B. Observation Equation Non-Linear (previously estimated coordinates and covariance matrix) 
clear all
clc
% Given

c = 562.100 ; % in meter
a = 623.800 ;% in meter
b = 746.838 ;% in meter
A = (pi/180)*(dms2degrees(54,44,50)); % in radians
B = (pi/180)*(dms2degrees(77,52,10)); % in radians
C = (pi/180)*(dms2degrees(47,22,55)); % in radians

Lb = [c;a;b;A;B;C];
disp('Onservation Matrix Lb:');
disp(Lb);
fprintf('-------------------------------------------------------------\n');

% Error - covariances we have

e1 =  5/1000 ; % in mm
e2 =  5/1000 ;% in mm
e3 =  5/1000 ;% in mm
e4 = (pi/180)*dms2degrees(0,0,5);
e5 = (pi/180)*dms2degrees(0,0,5);
e6 = (pi/180)*dms2degrees(0,0,5);


 % sigma lblb
E_lb = diag([e1^2,e2^2,e3^2,e4^2,e5^2,e6^2]);
apriori = 1; % sigma_0 square
P1 = apriori * inv(E_lb);
Qlb = inv(P1);
disp(" Weight Matirx P:");
%disp(P);
fprintf('-------------------------------------------------------------\n');


% Number of observations
n = 6;
disp('Number of observation:');
disp(n);
% No. of Paramters
u = 6;
disp('Number of Parameters:');
disp(u);
% Degree f freedom
r = 0;
disp('Degree of Freedom:');
disp(r);
fprintf('-------------------------------------------------------------\n');

disp('Since Degree of Freedom is 0 so we apply constarints to solve them:');
fprintf('-------------------------------------------------------------\n');

% intial coordinates

ax_i = 1000.0 ; % in meters
ay_i = 1000.0 ; % in meters
bx_i = 1386.9 ; % in meters
by_i = 1407.3 ; % in meters
cx_i = 1739.1 ; % in meters
cy_i =  892.8 ; % in meters


X0 = [ax_i; ay_i; bx_i; by_i; cx_i; cy_i];
fprintf('Initial Coordinates Matrix X0 (Up to 3 decimal places):\n');
fprintf('%.3f\n', X0);

fprintf('-------------------------------------------------------------\n');

for i= 1:100

% Initial observations

syms ax ay bx by cx cy

f1 = sqrt( (ax - bx)^2 + (ay - by)^2 );
f2 = sqrt( (bx - cx)^2 + (by - cy)^2 );
f3 = sqrt( (ax - cx)^2 + (ay - cy)^2 );
f4 = (pi + atan((cx - ax) / (cy - ay))) - (atan((bx - ax) / (by - ay)));
f5 = (pi + atan((ax - bx) / (ay - by))) - (pi+(atan((cx - bx) / (cy - by))));
f6 = ((2 * pi) + (atan((bx - cx) / (by - cy)))) - ((2 * pi) +(atan((ax - cx) / (ay - cy))));


equ = [f1,f2,f3,f4,f5,f6]';
L0 = double(subs(equ,[ax,ay,bx,by,cx,cy],X0'));
disp('Initial Onservation Matrix L0:');
disp(L0);

fprintf('-------------------------------------------------------------\n');

% L Matrix

L5 = Lb -L0;
disp('Matrix L = Lb - L0:');
%disp(L);
fprintf('-------------------------------------------------------------\n');
% Preparing Design matrix A

parameter_1 = [ax,ay,bx,by,cx,cy];
equations = [f1,f2,f3,f4,f5,f6]';

a = jacobian(equations, [ax,ay,bx,by,cx,cy]);
A1=double(subs(a,[ax,ay,bx,by,cx,cy],X0'));

% Display the Jacobian matrix
disp("A: Design Matrix");
%disp(A1);

fprintf('-------------------------------------------------------------\n');

disp("II: previously estimated coordinates and covariance matrix\n");
disp("4 coordinates Xa, Ya, Xb, Yb and Cofactor matrix Qab");

fprintf('-------------------------------------------------------------\n');
cxa = 999.9336;
cya = 1000.0201;
cxb = 1386.9336;
cyb = 1407.7217;
Qab = [0.022822, -0.001497, 0.021063, -0.002197;
       -0.001497, 0.005873, -0.000997, 0.005955;
       0.021063, -0.000997, 0.020087, -0.001469;
       -0.002197, 0.005955, -0.001469, 0.006280];
P2 = inv(Qab);
L2 = [cxa;cya;cxb;cyb];


disp("Number of costarints or Number of conditions against parameters:");
s = 4;
disp("S")
disp(s)
fprintf('-------------------------------------------------------------\n');

% Compute coefficient matrix C
syms ax ay bx by cx cy

f_c1 = ax;
f_c2 = ay;
f_c3 = bx;
f_c4 = by;


parameter_1 = [ax,ay,bx,by,cx,cy];
equations_c = [f_c1,f_c2,f_c3,f_c4];

c = jacobian(equations_c, [ax,ay,bx,by,cx,cy]);
A2 = double(subs(c,[ax,ay,bx,by],[cxa,cya,cxb,cyb]));
% Display the Jacobian matrix
disp("A2: Design Matrix of constraints");

A = [A1;A2];
P = blkdiag(P1, P2);
L1 = [Lb;L2];
L01 = [L0;L2];
L = L1 - L01;
N = A'*P*A;
N_inv = inv(N);

U = A'*P*L;
disp("N and U is computed:n")
fprintf('-------------------------------------------------------------\n');
% Compute delta X from inverse of quasi normal equation 
delta_X = N_inv*U


fprintf('-------------------------------------------------------------\n');

% Update approximate parameter vector 

Xa = X0+ delta_X;

fprintf('-------------------------------------------------------------\n');

% Residual V

V_linear = (A * delta_X) - L
fprintf('-------------------------------------------------------------\n');

% VTPV linear

VTPV_linear = V_linear'*P*V_linear

fprintf('-------------------------------------------------------------\n');
% Evaluate mathematical model F(X_a) = La

La = L1+ V_linear;

fprintf('-------------------------------------------------------------\n');
fprintf('-------------------------------------------------------------\n');

%tolerance = 10^-8;

disp('Iteration no')
disp(i)
fprintf('--------------------------------------------------------------\n');
%convergence based on |delta_X| < 0.001
  
  if abs(delta_X < 0.001);
               % A posteriori varience
        sigma_aposteiori= VTPV_linear/(s) ;
        disp('A posteriori varience')
        disp(sigma_aposteiori)
       
        break
        else
        disp('Convergence criteria reached')
        fprintf('\n')
          %  adjusted parameters become approximate parameters
         X0 = Xa;
        % adjusted observation become approximate observations
         L0 = La;

   end
end
fprintf('--------------------------------------------------------------\n');
fprintf('Final Coordinates Matrix Xa (Up to 3 decimal places):\n');
fprintf('%.3f\n', Xa);

fprintf('--------------------------------------------------------------\n');
fprintf('Adjusted Observation La (Up to 4 decimal places):\n');
fprintf('%.4f\n', La);
fprintf('--------------------------------------------------------------\n');
La1 = La(1);
La2 = La(2);
La3 = La(3);
La4 = deg2dms((180/pi)*La(4));
La5 = deg2dms((180/pi)*La(5));
La6 = deg2dms((180/pi)*La(6));


disp("Adjusted Observation")
disp(La1);
disp(La2);
disp(La3);
disp(La4);
disp(La5);
disp(La6);
fprintf('--------------------------------------------------------------\n');
disp("Residual Vector V:");
fprintf('%.12f\n',V_linear);
fprintf('--------------------------------------------------------------\n');
disp("Residual")
V01 = 1000*V_linear(1);
V02 = 1000*V_linear(2);
V03 = 1000*V_linear(3);
V04 = deg2dms((180/pi)*V_linear(4));
V05 = deg2dms((180/pi)*V_linear(5));
V06 = deg2dms((180/pi)*V_linear(6));

disp(V01);
disp(V02);
disp(V03);
disp(V04);
disp(V05);
disp(V06);
fprintf('--------------------------------------------------------------\n');

% Various Checks

  fprintf('------------------------Checks----------------------------\n');

% Check 1 for A'PV = 0
V = V_linear;
ATPV= A'*P*V;

if ATPV < 10^-3
    fprintf('Then ATPV is 0 and check successful\n')
else 
    fprintf('Unsuccessful: ATPV is not zero\n')
end

fprintf('--------------------------------------------------------------\n');

% Check 2 Calculating V'PV by three methods
fprintf("\nCalculating V'PV by three methods:\n");
fprintf("V'PV = ")
VTPV= V'*P*V;
disp(double(VTPV));

fprintf('--------------------------------------------------------------\n');

fprintf("-V'PLb = ")
VTPL=-V'*P*L;
disp(double(VTPL));

fprintf('--------------------------------------------------------------\n');

fprintf("-Lb'PV = ");
LTPV=-L'*P*V;
disp(double(LTPV));

fprintf('--------------------------------------------------------------\n\n\n');

% Stochastic Part 
disp('Stocastic Part')

 fprintf('--------------------------------------------------------------\n');

 % Computation of weighted coefficient matrix for observed Quantities
 Q_Lb = inv(P1);
 disp('Weighted coefficient matrix for Observed Quantities (Q_Lb) (6 x 6)-');
 disp(Q_Lb);

fprintf('--------------------------------------------------------------\n');

 %Computation of weighted coefficient matrix for observed Quantities
 Q_Xa = inv(N);
 disp('Weighted Coefficient matrix for Adjusted Parameters (Q_Xa) (6 x 6)');
 disp(Q_Xa);

 fprintf('--------------------------------------------------------------\n');

 % Computation of weighted coefficient matrix for adjusted observation
Q_La = A*inv(N)*A';
Q_La = Q_La(1:6, 1:6);
disp('Weighted Coefficient matrix for Adjusted Observation (Q_La)(6 x 6)');
 disp(Q_La);

 fprintf('--------------------------------------------------------------\n');

 % Computation of weighted coefficient matrix for residual
Q_V = Q_Lb - Q_La;
disp('Weighted Coefficient matrix for Residual (Q_V) (6 x 6)');
 disp(Q_V);

 fprintf('--------------------------------------------------------------\n');
apost = sigma_aposteiori;
 % Covariance matrix for Observed Values
 sigma_Lb = apost*Q_Lb;
 disp('Covariance Matrix of observation Q_Lb (6 x 6)-');
 disp(sigma_Lb);

 fprintf('--------------------------------------------------------------\n');

 % A posteriori covariance matrix for parameters
 sigma_Xa = apost*Q_Xa;
 disp('Covariance Matrix of Parameters Q_Xa(6 x 6)-');
 disp(sigma_Xa);

fprintf('--------------------------------------------------------------\n');

 % A posteriori covariance matrix for adjusted observation
 sigma_La = apost*Q_La;
 disp('Covariance Matrix of Adjusted Values Q_La (6 x 6)-');
 disp(sigma_La);

fprintf('--------------------------------------------------------------\n');

 % A poesteriori covariance matrix for residuals
 sigma_V = apost*Q_V;
 disp('Covariance Matrix of Residual Q_v (6 x 6) ');
 disp(sigma_V);

 fprintf('--------------------------------------------------------------\n');

 % Post processing

% Pope's tau Test 

% tinv of machine learning toolbox used with 0.95 as confidence interval
% and r as degree of fredom

% Calculate the t-value for the 0.95 confidence interval and given degrees of freedom
t_v1 = tinv(0.95, r);

% Calculate the threshold for the test statistic
T_v = t_v1 * sqrt(r) / sqrt(r - 1 + t_v1^2);

% Assuming V is a vector, Test statistics
V = V;
for i = 1:6
    % Assuming sigma_0_sqr is a predefined variable
    T_i = V(i) / apost * sqrt(Q_V(i, i));
    
    % Perform the test
    if T_i > T_v
        disp(['Hypothesis rejected for element ' num2str(i)]);
    else
        disp(['Hypothesis accepted for element ' num2str(i)]);
    end
end

% errror elipse for local coordinate
s_0 = sqrt(apost);
a_local = s_0*sqrt(Q_Xa(1,1));
b_local = s_0*sqrt(Q_Xa(2,2));


% errror elipse for global coordinate

% for rotation angle

t = (1/2)*atan(Q_Xa(1,2)/(Q_Xa(2,2)-Q_Xa(1,1)));
R = [sin(t), cos(t); -cos(t), sin(t)];
Q = [Q_Xa(1,1),Q_Xa(1,2);
     Q_Xa(2,1),Q_Xa(2,2)];
Q_zz = R*Q*R';
a_global =  s_0*sqrt(Q_zz(1,1));
b_global =  s_0*sqrt(Q_zz(2,2));


% Plot Error ellipse

covariance_matrix = Q_Xa;  % Covariance matrix

% Number of points on the ellipse
num_points = 100;

% Generate points on the unit circle
theta = linspace(0, 2 * pi, num_points);
points_on_circle1= [a_global*cos(theta); b_global*sin(theta)];
points_on_circle2 = [a_local*cos(theta); b_local*sin(theta)];

% Plot the ellipse
figure(4);
plot(points_on_circle1(1, :), points_on_circle1(2, :), '-');
hold on;
plot(points_on_circle2(1, :), points_on_circle2(2, :), '-');
title('Error Ellipse Point A:priviously estimate coordinates and cofactor matrix');
xlabel('X-axis');
ylabel('Y-axis');
hold off;
grid on;
axis equal;
fprintf('------------------------------------------------------------------\n');

% errror elipse for local coordinate
s_0 = sqrt(apost);
a_local = s_0*sqrt(Q_Xa(3,3));
b_local = s_0*sqrt(Q_Xa(4,4));


% errror elipse for global coordinate

% for rotation angle

t = (1/2)*atan(Q_Xa(3,4)/(Q_Xa(4,4)-Q_Xa(3,3)));
R = [sin(t), cos(t); -cos(t), sin(t)];
Q = [Q_Xa(3,3),Q_Xa(3,4);
     Q_Xa(4,3),Q_Xa(4,4)];
Q_zz = R*Q*R';
a_global =  s_0*sqrt(Q_zz(1,1));
b_global =  s_0*sqrt(Q_zz(2,2));


% Plot Error ellipse

covariance_matrix = Q_Xa;  % Covariance matrix

% Number of points on the ellipse
num_points = 100;

% Generate points on the unit circle
theta = linspace(0, 2 * pi, num_points);
points_on_circle1= [a_global*cos(theta); b_global*sin(theta)];
points_on_circle2 = [a_local*cos(theta); b_local*sin(theta)];

% Plot the ellipse
figure(5);
plot(points_on_circle1(1, :), points_on_circle1(2, :), '-');
hold on;
plot(points_on_circle2(1, :), points_on_circle2(2, :), '-');
title('Error Ellipse Point B:priviously estimate coordinates and cofactor matrix');
xlabel('X-axis');
ylabel('Y-axis');
hold off;
grid on;
axis equal;
fprintf('------------------------------------------------------------------\n');

% errror elipse for local coordinate
s_0 = sqrt(apost);
a_local = s_0*sqrt(Q_Xa(5,5));
b_local = s_0*sqrt(Q_Xa(6,6));


% errror elipse for global coordinate

% for rotation angle

t = (1/2)*atan(Q_Xa(5,6)/(Q_Xa(6,6)-Q_Xa(5,5)));
R = [sin(t), cos(t); -cos(t), sin(t)];
Q = [Q_Xa(5,5),Q_Xa(5,6);
     Q_Xa(5,6),Q_Xa(6,6)];
Q_zz = R*Q*R';
a_global =  s_0*sqrt(Q_zz(1,1));
b_global =  s_0*sqrt(Q_zz(2,2));


% Plot Error ellipse

covariance_matrix = Q_Xa;  % Covariance matrix

% Number of points on the ellipse
num_points = 100;

% Generate points on the unit circle
theta = linspace(0, 2 * pi, num_points);
points_on_circle1= [a_global*cos(theta); b_global*sin(theta)];
points_on_circle2 = [a_local*cos(theta); b_local*sin(theta)];

% Plot the ellipse
figure(6);
plot(points_on_circle1(1, :), points_on_circle1(2, :), '-');
hold on;
plot(points_on_circle2(1, :), points_on_circle2(2, :), '-');
title('Error Ellipse Point C:priviously estimate coordinates and cofactor matrix');
xlabel('X-axis');
ylabel('Y-axis');
hold off;
grid on;
axis equal;
fprintf('------------------------------------------------------------------\n');

fprintf("Chi-Square Test: \n");

alph = 0.05;  % Significance level
DOF = s;
% Finding the critical value for a chi-square distribution
critical_value1 = chi2inv((alph/2),DOF);
critical_value2 = chi2inv((1 - (alph/2)),DOF);

Chi= VTPV/apost;

if Chi > critical_value1 && Chi < critical_value2
        fprintf("Chi-Square test succefully done \n");
    else
        fprintf("Chi-Square test fails \n");
end

%% Q1 C. Observation Equation Non-Linear (Inner Constraints) 
clear all
clc

% Given

c = 562.100 ; % in meter
a = 623.800 ;% in meter
b = 746.838 ;% in meter
A = (pi/180)*(dms2degrees(54,44,50)); % in radians
B = (pi/180)*(dms2degrees(77,52,10)); % in radians
C = (pi/180)*(dms2degrees(47,22,55)); % in radians

Lb = [c;a;b;A;B;C];
disp('Onservation Matrix Lb:');
disp(Lb);
fprintf('-------------------------------------------------------------\n');

% Error - covariances we have

e1 =  5/1000 ; % in mm
e2 =  5/1000 ;% in mm
e3 =  5/1000 ;% in mm
e4 = (pi/180)*dms2degrees(0,0,5);
e5 = (pi/180)*dms2degrees(0,0,5);
e6 = (pi/180)*dms2degrees(0,0,5);


 % sigma lblb
E_lb = diag([e1^2,e2^2,e3^2,e4^2,e5^2,e6^2]);
apriori = 1; % sigma_0 square
P = apriori * inv(E_lb);

disp(" Weight Matirx P:");
%disp(P);
fprintf('-------------------------------------------------------------\n');


% Number of observations
n = 6;
disp('Number of observation:');
disp(n);
% No. of Paramters
u = 6;
disp('Number of Parameters:');
disp(u);
% Degree f freedom
r = 0;
disp('Degree of Freedom:');
disp(r);
fprintf('-------------------------------------------------------------\n');

disp('Since Degree of Freedom is 0 so we apply constarints to solve them:');
fprintf('-------------------------------------------------------------\n');

disp("Number of costarints or Number of conditions against parameters:");
s = 4;
disp("S")
disp(s)
fprintf('-------------------------------------------------------------\n');
% intial coordinates

ax_i = 1000.0 ; % in meters
ay_i = 1000.0 ; % in meters
bx_i = 1386.9 ; % in meters
by_i = 1407.3 ; % in meters
cx_i = 1739.1 ; % in meters
cy_i =  892.8 ; % in meters


X0 = [ax_i; ay_i; bx_i; by_i; cx_i; cy_i];
fprintf('Initial Coordinates Matrix X0 (Up to 3 decimal places):\n');
fprintf('%.3f\n', X0);

fprintf('-------------------------------------------------------------\n');

for i= 1:100

% Initial observations

syms ax ay bx by cx cy

f1 = sqrt( (ax - bx)^2 + (ay - by)^2 );
f2 = sqrt( (bx - cx)^2 + (by - cy)^2 );
f3 = sqrt( (ax - cx)^2 + (ay - cy)^2 );
f4 = (pi + atan((cx - ax) / (cy - ay))) - (atan((bx - ax) / (by - ay)));
f5 = (pi + atan((ax - bx) / (ay - by))) - (pi+(atan((cx - bx) / (cy - by))));
f6 = ((2 * pi) + (atan((bx - cx) / (by - cy)))) - ((2 * pi) +(atan((ax - cx) / (ay - cy))));


equ = [f1,f2,f3,f4,f5,f6]';
L0 = double(subs(equ,[ax,ay,bx,by,cx,cy],X0'));
disp('Initial Onservation Matrix L0:');
disp(L0);

fprintf('-------------------------------------------------------------\n');

% L Matrix

L = Lb -L0;
disp('Matrix L = Lb - L0:');
%disp(L);
fprintf('-------------------------------------------------------------\n');
% Preparing Design matrix A

parameter_1 = [ax,ay,bx,by,cx,cy];
equations = [f1,f2,f3,f4,f5,f6]';

a = jacobian(equations, [ax,ay,bx,by,cx,cy]);
A=double(subs(a,[ax,ay,bx,by,cx,cy],X0'));

% Display the Jacobian matrix
disp("A: Design Matrix");
%disp(A);

fprintf('-------------------------------------------------------------\n');

N1 = A'*P*A ;


U = A'*P*L;
disp("N and U is computed:n")
fprintf('-------------------------------------------------------------\n');

disp("III: Inner Constraints/ Free net Analysis\n");
disp("1 Azimuth is known which fill not allow our network to rotate");

fprintf('-------------------------------------------------------------\n');


Alpha = (pi/180)*(dms2degrees(43,30,00));

disp("Constarints we have");
fprintf('-------------------------------------------------------------\n');




% Compute coefficient matrix C
syms ax ay bx by cx cy
% ax = cxa;
% ay = cxb;
% bx = 1386.9;
% by = 1407.3;

f_c1 = atan((bx - ax) / (by - ay));


parameter_1 = [ax,ay,bx,by,cx,cy];
equations_c = [f_c1];

c = jacobian(equations_c, [ax,ay,bx,by,cx,cy]);
C = double(subs(c,[ax,ay,bx,by,cx,cy],[X0(1),X0(2),X0(3),X0(4),X0(5),X0(6)]));
% Display the Jacobian matrix
disp("C: Design Matrix of constraints");

fprintf('-------------------------------------------------------------\n');

% Miscloure vectoe W_c

W_c = [atan((bx - ax) / (by - ay))-Alpha];

W_c = double(subs(W_c,[ax,ay,bx,by,cx,cy],[X0(1),X0(2),X0(3),X0(4),X0(5),X0(6)]));
disp("W_c: Misclosure vector");

fprintf('-------------------------------------------------------------\n');
 N = N1 + C'*C;

fprintf('-------------------------------------------------------------\n');
% Perform Singular Value Decomposition
[U, S, V] = svd(N);

S= pinv(S);
% as N is not invertable computing pseudo inverse 
N_plus = V * S * U' ;
Nplus= pinv(N);

U = A'*P*L;

% Compute delta X from inverse of quasi normal equation 

delta_X = (Nplus*U);

fprintf('-------------------------------------------------------------\n');

% Update approximate parameter vector 

Xa = X0 + delta_X;

fprintf('-------------------------------------------------------------\n');
fprintf('-------------------------------------------------------------\n');

% Residual V

V_linear = A * delta_X - L;
fprintf('-------------------------------------------------------------\n');

% VTPV linear

VTPV_linear = V_linear'*P*V_linear;
fprintf('-------------------------------------------------------------\n');

fprintf('-------------------------------------------------------------\n');

% Evaluate mathematical model F(X_a) = La

La = [sqrt( (Xa(1) - Xa(3))^2 + (Xa(2) - Xa(4))^2 );
    sqrt( (Xa(3) - Xa(5))^2 + (Xa(4) - Xa(6))^2 );
    sqrt( (Xa(1) - Xa(5))^2 + (Xa(2) - Xa(6))^2 );
    (pi + atan((Xa(5) - Xa(1)) / (Xa(6) - Xa(2)))) - (atan((Xa(3) - Xa(1)) / (Xa(4) - Xa(2))));
    (pi + atan((Xa(1) - Xa(3)) / (Xa(2) - Xa(4)))) - (pi+(atan((Xa(5) - Xa(3)) / (Xa(6) - Xa(4)))));
    ((2 * pi) + (atan((Xa(3) - Xa(5))/ (Xa(4) - Xa(6))))) - ((2 * pi) +(atan((Xa(1) - Xa(5)) / (Xa(2) - Xa(6)))))];

fprintf('-------------------------------------------------------------\n');
% Compute VTPV non linear

V_nonlinear = La - Lb;

% Computing  VTPV nonlinear
VTPV_nonlinear =  V_nonlinear'*P*V_nonlinear;
tolerance = 10^-8;

fprintf('--------------------------------------------------------------\n');

disp('Iteration no')
disp(i)
fprintf('--------------------------------------------------------------\n');
%convergence based on |VTPV_nonlinear - VTPV_linear| < tolerance
   if abs(VTPV_nonlinear - VTPV_linear) <tolerance;
               % A posteriori varience
        sigma_aposteiori= VTPV_linear/(s) ;
        disp('A posteriori varience')
        disp(sigma_aposteiori)

        break
        else
        disp('Convergence criteria reached')
        fprintf('\n')
          %  adjusted parameters become approximate parameters
         X0 = Xa;
        % adjusted observation become approximate observations
         L0 = La

    end
end

fprintf('--------------------------------------------------------------\n');

fprintf('Final Coordinates Matrix Xa (Up to 3 decimal places):\n');
fprintf('%.3f\n', Xa);

fprintf('--------------------------------------------------------------\n');
fprintf('Adjusted Observation La (Up to 4 decimal places):\n');
fprintf('%.4f\n', La);
fprintf('--------------------------------------------------------------\n');

La1 = La(1);
La2 = La(2);
La3 = La(3);
La4 = deg2dms((180/pi)*La(4));
La5 = deg2dms((180/pi)*La(5));
La6 = deg2dms((180/pi)*La(6));
LA = [La(1);La(2);La(3);La(4);La(5);La(6)];

disp("Adjusted Observation")
disp(La1);
disp(La2);
disp(La3);
disp(La4);
disp(La5);
disp(La6);
fprintf('--------------------------------------------------------------\n');
disp("Residual Vector V:");
fprintf('%.12f\n',V_linear);
fprintf('--------------------------------------------------------------\n');

disp("Residual")
V01 = 1000*V_linear(1);
V02 = 1000*V_linear(2);
V03 = 1000*V_linear(3);
V04 = deg2dms((180/pi)*V_linear(4));
V05 = deg2dms((180/pi)*V_linear(5));
V06 = deg2dms((180/pi)*V_linear(6));

disp(V01);
disp(V02);
disp(V03);
disp(V04);
disp(V05);
disp(V06);
fprintf('--------------------------------------------------------------\n');

% Various Checks

  fprintf('------------------------Checks----------------------------\n');

% Check 1 for A'PV = 0
V = V_linear;
ATPV= A'*P*V;

if ATPV < 10^-3
    fprintf('Then ATPV is 0 and check successful\n')
else 
    fprintf('Unsuccessful: ATPV is not zero\n')
end

fprintf('--------------------------------------------------------------\n');

% Check 2 Calculating V'PV by three methods
fprintf("\nCalculating V'PV by three methods:\n");
fprintf("V'PV = ")
VTPV= V'*P*V;
disp(double(VTPV));

fprintf('--------------------------------------------------------------\n');

fprintf("-V'PLb = ")
VTPL=-V'*P*L;
disp(double(VTPL));

fprintf('--------------------------------------------------------------\n');

fprintf("-Lb'PV = ");
LTPV=-L'*P*V;
disp(double(LTPV));

fprintf('--------------------------------------------------------------\n\n\n');
% Stochastic Part 
disp('Stocastic Part')

 fprintf('--------------------------------------------------------------\n');

 % Computation of weighted coefficient matrix for observed Quantities
 Q_Lb = inv(P);
 disp('Weighted coefficient matrix for Observed Quantities (Q_Lb) (6 x 6)-');
 disp(Q_Lb);

fprintf('--------------------------------------------------------------\n');

 %Computation of weighted coefficient matrix for observed Quantities
 Q_Xa = inv(Nplus)-(inv(Nplus)*C'*inv(C*inv(Nplus)*C')*C*inv(Nplus));
 disp('Weighted Coefficient matrix for Adjusted Parameters (Q_Xa) (6 x 6)');
 disp(Q_Xa);
 fprintf('--------------------------------------------------------------\n');

 % Computation of weighted coefficient matrix for adjusted observation
Q_La = A*inv(Nplus)*A';
disp('Weighted Coefficient matrix for Adjusted Observation (Q_La)(6 x 6)');
 disp(Q_La);

 fprintf('--------------------------------------------------------------\n');

 % Computation of weighted coefficient matrix for residual
Q_V = Q_Lb - Q_La;
disp('Weighted Coefficient matrix for Residual (Q_V) (6 x 6)');
 disp(Q_V);

 fprintf('--------------------------------------------------------------\n');
apost = sigma_aposteiori;
 % Covariance matrix for Observed Values
 sigma_Lb = apost*Q_Lb;
 disp('Covariance Matrix of observation Q_Lb (6 x 6)-');
 disp(sigma_Lb);

 fprintf('--------------------------------------------------------------\n');

 % A posteriori covariance matrix for parameters
 sigma_Xa = apost*Q_Xa;
 disp('Covariance Matrix of Parameters Q_Xa(6 x 6)-');
 disp(sigma_Xa);

fprintf('--------------------------------------------------------------\n');

 % A posteriori covariance matrix for adjusted observation
 sigma_La = apost*Q_La;
 disp('Covariance Matrix of Adjusted Values Q_La (6 x 6)-');
 disp(sigma_La);

fprintf('--------------------------------------------------------------\n');

 % A poesteriori covariance matrix for residuals
 sigma_V = apost*Q_V;
 disp('Covariance Matrix of Residual Q_v (6 x 6) ');
 disp(sigma_V);

 fprintf('--------------------------------------------------------------\n');

 % Post processing

% Pope's tau Test 

% tinv of machine learning toolbox used with 0.95 as confidence interval
% and r as degree of fredom

% Calculate the t-value for the 0.95 confidence interval and given degrees of freedom
t_v1 = tinv(0.95, r);

% Calculate the threshold for the test statistic
T_v = t_v1 * sqrt(r) / sqrt(r - 1 + t_v1^2);

% Assuming V is a vector, Test statistics
V = V;
for i = 1:length(V)
    % Assuming sigma_0_sqr is a predefined variable
    T_i = V(i) / apost * sqrt(Q_V(i, i));
    
    % Perform the test
    if T_i > T_v
        disp(['Hypothesis rejected for element ' num2str(i)]);
    else
        disp(['Hypothesis accepted for element ' num2str(i)]);
    end
end


% errror elipse for local coordinate
s_0 = sqrt(apost);
a_local = s_0*sqrt(Q_Xa(1,1));
b_local = s_0*sqrt(Q_Xa(2,2));


% errror elipse for global coordinate

% for rotation angle

t = (1/2)*atan(Q_Xa(1,2)/(Q_Xa(2,2)-Q_Xa(1,1)));
R = [sin(t), cos(t); -cos(t), sin(t)];
Q = [Q_Xa(1,1),Q_Xa(1,2);
     Q_Xa(2,1),Q_Xa(2,2)];
Q_zz = R*Q*R';
a_global =  s_0*sqrt(Q_zz(1,1));
b_global =  s_0*sqrt(Q_zz(2,2));


% Plot Error ellipse

covariance_matrix = Q_Xa;  % Covariance matrix

% Number of points on the ellipse
num_points = 100;

% Generate points on the unit circle
theta = linspace(0, 2 * pi, num_points);
points_on_circle1= [a_global*cos(theta); b_global*sin(theta)];
points_on_circle2 = [a_local*cos(theta); b_local*sin(theta)];

% Plot the ellipse
figure(7);
plot(points_on_circle1(1, :), points_on_circle1(2, :), '-');
hold on;
plot(points_on_circle2(1, :), points_on_circle2(2, :), '-');
title('Error Ellipse Point A III: Inner Constraints/ Free net Analysis');
xlabel('X-axis');
ylabel('Y-axis');
hold off;
grid on;
axis equal;
fprintf('------------------------------------------------------------------\n');

% errror elipse for local coordinate
s_0 = sqrt(apost);
a_local = s_0*sqrt(Q_Xa(3,3));
b_local = s_0*sqrt(Q_Xa(4,4));


% errror elipse for global coordinate

% for rotation angle

t = (1/2)*atan(Q_Xa(3,4)/(Q_Xa(4,4)-Q_Xa(3,3)));
R = [sin(t), cos(t); -cos(t), sin(t)];
Q = [Q_Xa(3,3),Q_Xa(3,4);
     Q_Xa(4,3),Q_Xa(4,4)];
Q_zz = R*Q*R';
a_global =  s_0*sqrt(Q_zz(1,1));
b_global =  s_0*sqrt(Q_zz(2,2));


% Plot Error ellipse

covariance_matrix = Q_Xa;  % Covariance matrix

% Number of points on the ellipse
num_points = 100;

% Generate points on the unit circle
theta = linspace(0, 2 * pi, num_points);
points_on_circle1= [a_global*cos(theta); b_global*sin(theta)];
points_on_circle2 = [a_local*cos(theta); b_local*sin(theta)];

% Plot the ellipse
figure(8);
plot(points_on_circle1(1, :), points_on_circle1(2, :), '-');
hold on;
plot(points_on_circle2(1, :), points_on_circle2(2, :), '-');
title('Error Ellipse Point B III: Inner Constraints/ Free net Analysis');
xlabel('X-axis');
ylabel('Y-axis');
hold off;
grid on;
axis equal;
fprintf('------------------------------------------------------------------\n');

% errror elipse for local coordinate
s_0 = sqrt(apost);
a_local = s_0*sqrt(Q_Xa(5,5));
b_local = s_0*sqrt(Q_Xa(6,6));


% errror elipse for global coordinate

% for rotation angle

t = (1/2)*atan(Q_Xa(5,6)/(Q_Xa(6,6)-Q_Xa(5,5)));
R = [sin(t), cos(t); -cos(t), sin(t)];
Q = [Q_Xa(5,5),Q_Xa(5,6);
     Q_Xa(5,6),Q_Xa(6,6)];
Q_zz = R*Q*R';
a_global =  s_0*sqrt(Q_zz(1,1));
b_global =  s_0*sqrt(Q_zz(2,2));


% Plot Error ellipse

covariance_matrix = Q_Xa;  % Covariance matrix

% Number of points on the ellipse
num_points = 100;

% Generate points on the unit circle
theta = linspace(0, 2 * pi, num_points);
points_on_circle1= [a_global*cos(theta); b_global*sin(theta)];
points_on_circle2 = [a_local*cos(theta); b_local*sin(theta)];

% Plot the ellipse
figure(9);
plot(points_on_circle1(1, :), points_on_circle1(2, :), '-');
hold on;
plot(points_on_circle2(1, :), points_on_circle2(2, :), '-');
title('Error Ellipse Point C III: Inner Constraints/ Free net Analysis');
xlabel('X-axis');
ylabel('Y-axis');
hold off;
grid on;
axis equal;
fprintf('------------------------------------------------------------------\n');

fprintf("Chi-Square Test: \n");

alph = 0.05;  % Significance level
DOF = s;
% Finding the critical value for a chi-square distribution
critical_value1 = chi2inv((alph/2),DOF);
critical_value2 = chi2inv((1 - (alph/2)),DOF);

Chi= VTPV/apost;

if Chi > critical_value1 && Chi < critical_value2
        fprintf("Chi-Square test succefully done \n");
    else
        fprintf("Chi-Square test fails \n");
end

%% Q1 D. an over-constrained estimation constraints) 
clear all 
clc
% Given

c = 562.100 ; % in meter
a = 623.800 ;% in meter
b = 746.838 ;% in meter
A = (pi/180)*(dms2degrees(54,44,50)); % in radians
B = (pi/180)*(dms2degrees(77,52,10)); % in radians
C = (pi/180)*(dms2degrees(47,22,55)); % in radians

Lb = [c;a;b;A;B;C];
disp('Onservation Matrix Lb:');
disp(Lb);
fprintf('-------------------------------------------------------------\n');

% Error - covariances we have

e1 =  5/1000 ; % in mm
e2 =  5/1000 ;% in mm
e3 =  5/1000 ;% in mm
e4 = (pi/180)*dms2degrees(0,0,5);
e5 = (pi/180)*dms2degrees(0,0,5);
e6 = (pi/180)*dms2degrees(0,0,5);


 % sigma lblb
E_lb = diag([e1^2,e2^2,e3^2,e4^2,e5^2,e6^2]);
apriori = 1; % sigma_0 square
P = apriori * inv(E_lb);

disp(" Weight Matirx P:");
%disp(P);
fprintf('-------------------------------------------------------------\n');


% Number of observations
n = 6;
disp('Number of observation:');
disp(n);
% No. of Paramters
u = 6;
disp('Number of Parameters:');
disp(u);
% Degree f freedom
r = 0;
disp('Degree of Freedom:');
disp(r);
fprintf('-------------------------------------------------------------\n');

disp('Since Degree of Freedom is 0 so we apply constarints to solve them:');
fprintf('-------------------------------------------------------------\n');

% intial coordinates

ax_i = 1000.0 ; % in meters
ay_i = 1000.0 ; % in meters
bx_i = 1386.9 ; % in meters
by_i = 1407.3 ; % in meters
cx_i = 1739.1 ; % in meters
cy_i =  892.8 ; % in meters


X0 = [ax_i; ay_i; bx_i; by_i; cx_i; cy_i];
fprintf('Initial Coordinates Matrix X0 (Up to 3 decimal places):\n');
fprintf('%.3f\n', X0);

fprintf('-------------------------------------------------------------\n');
for i= 1:100

% Initial observations

syms ax ay bx by cx cy

f1 = sqrt( (ax - bx)^2 + (ay - by)^2 );
f2 = sqrt( (bx - cx)^2 + (by - cy)^2 );
f3 = sqrt( (ax - cx)^2 + (ay - cy)^2 );
f4 = (pi + atan((cx - ax) / (cy - ay))) - (atan((bx - ax) / (by - ay)));
f5 = (pi + atan((ax - bx) / (ay - by))) - (pi+(atan((cx - bx) / (cy - by))));
f6 = ((2 * pi) + (atan((bx - cx) / (by - cy)))) - ((2 * pi) +(atan((ax - cx) / (ay - cy))));


equ = [f1,f2,f3,f4,f5,f6]';
L0 = double(subs(equ,[ax,ay,bx,by,cx,cy],X0'));
disp('Initial Onservation Matrix L0:');
disp(L0);

fprintf('-------------------------------------------------------------\n');

% L Matrix

L = Lb -L0;
disp('Matrix L = Lb - L0:');
%disp(L);
fprintf('-------------------------------------------------------------\n');
% Preparing Design matrix A

parameter_1 = [ax,ay,bx,by,cx,cy];
equations = [f1,f2,f3,f4,f5,f6]';

a = jacobian(equations, [ax,ay,bx,by,cx,cy]);
A=double(subs(a,[ax,ay,bx,by,cx,cy],X0'));

% Display the Jacobian matrix
disp("A: Design Matrix");
%disp(A);

fprintf('-------------------------------------------------------------\n');

N = A'*P*A ;


U = A'*P*L;
disp("N and U is computed:n")
fprintf('-------------------------------------------------------------\n');

disp("IV: Over Constraints\n");
disp("4 coordinates Xa, Ya, Xb, Yb is fixed ");

fprintf('-------------------------------------------------------------\n');

cxa = 999.9776; 
cya = 1000.0201;
cxb = 1386.9336;
cyb = 1407.7212;

disp("Over Constarints we have");
fprintf('-------------------------------------------------------------\n');

disp("Number of costarints or Number of conditions against parameters:");
s = 4;
disp("S")
disp(s)
fprintf('-------------------------------------------------------------\n');

% Compute coefficient matrix C
syms ax ay bx by cx cy
% ax = cxa;
% ay = cxb;
% bx = 1386.9;
% by = 1407.3;
f_c1 = ax;
f_c2 = ay;
f_c3 = bx;
f_c4 = by;


parameter_1 = [ax,ay,bx,by,cx,cy];
equations_c = [f_c1,f_c2,f_c3,f_c4];

c = jacobian(equations_c, [ax,ay,bx,by,cx,cy]);
C = double(subs(c,[ax,ay,bx,by,cx,cy],[X0(1),X0(2),X0(3),X0(4),X0(5),X0(6)]));
% Display the Jacobian matrix
disp("C: Design Matrix of constraints");

fprintf('-------------------------------------------------------------\n');

% Miscloure vectoe W_c

W_c = [-cxa+ax;-cya+ay;-cxb+bx;-cyb+by];

W_c = double(subs(W_c,[ax,ay,bx,by,cx,cy],[X0(1),X0(2),X0(3),X0(4),X0(5),X0(6)]));
disp("W_c: Misclosure vector");
disp(W_c);

fprintf('-------------------------------------------------------------\n');
N = N + (C'*C);
N_inv = inv(N);
% Compute K_c

K_c = -inv((C*N_inv*C'))*(C*N_inv*U + W_c)

disp("K_c:");

fprintf('-------------------------------------------------------------\n');

% Compute delta X from inverse of quasi normal equation 

delta_X = (N_inv*U + N_inv*C'*K_c);

fprintf('-------------------------------------------------------------\n');

% Update approximate parameter vector 

Xa = X0 + delta_X

fprintf('-------------------------------------------------------------\n');

% Residual V

V_linear = A * delta_X - L
fprintf('-------------------------------------------------------------\n');

% VTPV linear

VTPV_linear = V_linear'*P*V_linear
fprintf('-------------------------------------------------------------\n');

fprintf('-------------------------------------------------------------\n');

% Evaluate mathematical model F(X_a) = La

La = [sqrt( (Xa(1) - Xa(3))^2 + (Xa(2) - Xa(4))^2 );
    sqrt( (Xa(3) - Xa(5))^2 + (Xa(4) - Xa(6))^2 );
    sqrt( (Xa(1) - Xa(5))^2 + (Xa(2) - Xa(6))^2 );
    (pi + atan((Xa(5) - Xa(1)) / (Xa(6) - Xa(2)))) - (atan((Xa(3) - Xa(1)) / (Xa(4) - Xa(2))));
    (pi + atan((Xa(1) - Xa(3)) / (Xa(2) - Xa(4)))) - (pi+(atan((Xa(5) - Xa(3)) / (Xa(6) - Xa(4)))));
    ((2 * pi) + (atan((Xa(3) - Xa(5))/ (Xa(4) - Xa(6))))) - ((2 * pi) +(atan((Xa(1) - Xa(5)) / (Xa(2) - Xa(6)))))];

fprintf('-------------------------------------------------------------\n');
% Compute VTPV non linear

V_nonlinear = La - Lb

% Computing  VTPV nonlinear
VTPV_nonlinear =  V_nonlinear'*P*V_nonlinear;
tolerance = 10^-8;

fprintf('--------------------------------------------------------------\n');



disp('Iteration no')
disp(i)
fprintf('--------------------------------------------------------------\n');
%convergence based on |VTPV_nonlinear - VTPV_linear| < tolerance
   if abs(VTPV_nonlinear - VTPV_linear) <tolerance;
               % A posteriori varience
        sigma_aposteiori= VTPV_linear/(n+s-u) ;
        disp('A posteriori varience')
        disp(sigma_aposteiori)

        break
        else
        disp('Convergence criteria reached')
        fprintf('\n')
          %  adjusted parameters become approximate parameters
         X0 = Xa;
        % adjusted observation become approximate observations
         L0 = La




    end
end

fprintf('--------------------------------------------------------------\n');

fprintf('Final Coordinates Matrix Xa (Up to 3 decimal places):\n');
fprintf('%.3f\n', Xa);

fprintf('--------------------------------------------------------------\n');
fprintf('Adjusted Observation La (Up to 4 decimal places):\n');
fprintf('%.4f\n', La);
fprintf('--------------------------------------------------------------\n');
La1 = La(1);
La2 = La(2);
La3 = La(3);
La4 = deg2dms((180/pi)*La(4));
La5 = deg2dms((180/pi)*La(5));
La6 = deg2dms((180/pi)*La(6));


disp("Adjusted Observation")
disp(La1);
disp(La2);
disp(La3);
disp(La4);
disp(La5);
disp(La6);
fprintf('--------------------------------------------------------------\n');
disp("Residual Vector V:");
fprintf('%.12f\n',V_linear);
fprintf('--------------------------------------------------------------\n');
disp("Residual")
V01 = 1000*V_linear(1);
V02 = 1000*V_linear(2);
V03 = 1000*V_linear(3);
V04 = deg2dms((180/pi)*V_linear(4));
V05 = deg2dms((180/pi)*V_linear(5));
V06 = deg2dms((180/pi)*V_linear(6));

disp(V01);
disp(V02);
disp(V03);
disp(V04);
disp(V05);
disp(V06);
fprintf('--------------------------------------------------------------\n');

% Various Checks

  fprintf('------------------------Checks----------------------------\n');

% Check 1 for A'PV = 0
V = V_linear;
ATPV= A'*P*V;

if ATPV < 10^3
    fprintf('Then ATPV is 0 and check successful\n')
else 
    fprintf('Unsuccessful: ATPV is not zero\n')
end

fprintf('--------------------------------------------------------------\n');

% Check 2 Calculating V'PV by three methods
fprintf("\nCalculating V'PV by three methods:\n");
fprintf("V'PV = ")
VTPV= V'*P*V;
disp(double(VTPV));

fprintf('--------------------------------------------------------------\n');

fprintf("-V'PLb = ")
VTPL=-V'*P*L;
disp(double(VTPL));

fprintf('--------------------------------------------------------------\n');

fprintf("-Lb'PV = ");
LTPV=-L'*P*V;
disp(double(LTPV));

fprintf('--------------------------------------------------------------\n\n\n');

% Stochastic Part 
disp('Stocastic Part')

 fprintf('--------------------------------------------------------------\n');

 % Computation of weighted coefficient matrix for observed Quantities
 Q_Lb = inv(P);
 disp('Weighted coefficient matrix for Observed Quantities (Q_Lb) (6 x 6)-');
 disp(Q_Lb);

fprintf('--------------------------------------------------------------\n');

 %Computation of weighted coefficient matrix for observed Quantities
 Q_Xa = inv(N);
 disp('Weighted Coefficient matrix for Adjusted Parameters (Q_Xa) (6 x 6)');
 disp(Q_Xa);

 fprintf('--------------------------------------------------------------\n');

 % Computation of weighted coefficient matrix for adjusted observation
Q_La = A*inv(n)*A';
disp('Weighted Coefficient matrix for Adjusted Observation (Q_La)(6 x 6)');
 disp(Q_La);

 fprintf('--------------------------------------------------------------\n');

 % Computation of weighted coefficient matrix for residual
Q_V = Q_Lb - Q_La;
disp('Weighted Coefficient matrix for Residual (Q_V) (6 x 6)');
 disp(Q_V);

 fprintf('--------------------------------------------------------------\n');
apost = sigma_aposteiori;
 % Covariance matrix for Observed Values
 sigma_Lb = apost*Q_Lb;
 disp('Covariance Matrix of observation Q_Lb (6 x 6)-');
 disp(sigma_Lb);

 fprintf('--------------------------------------------------------------\n');

 % A posteriori covariance matrix for parameters
 sigma_Xa = apost*Q_Xa;
 disp('Covariance Matrix of Parameters Q_Xa(6 x 6)-');
 disp(sigma_Xa);

fprintf('--------------------------------------------------------------\n');

 % A posteriori covariance matrix for adjusted observation
 sigma_La = apost*Q_La;
 disp('Covariance Matrix of Adjusted Values Q_La (6 x 6)-');
 disp(sigma_La);

fprintf('--------------------------------------------------------------\n');

 % A poesteriori covariance matrix for residuals
 sigma_V = apost*Q_V;
 disp('Covariance Matrix of Residual Q_v (6 x 6) ');
 disp(sigma_V);

 fprintf('--------------------------------------------------------------\n');

 % Post processing

% Pope's tau Test 

% tinv of machine learning toolbox used with 0.95 as confidence interval
% and r as degree of fredom

% Calculate the t-value for the 0.95 confidence interval and given degrees of freedom
t_v1 = tinv(0.95, r);

% Calculate the threshold for the test statistic
T_v = t_v1 * sqrt(r) / sqrt(r - 1 + t_v1^2);

% Assuming V is a vector, Test statistics
V = V;
for i = 1:length(V)
    % Assuming sigma_0_sqr is a predefined variable
    T_i = V(i) / apost * sqrt(Q_V(i, i));
    
    % Perform the test
    if T_i > T_v
        disp(['Hypothesis rejected for element ' num2str(i)]);
    else
        disp(['Hypothesis accepted for element ' num2str(i)]);
    end
end

% errror elipse for local coordinate
s_0 = sqrt(apost);
a_local = s_0*sqrt(Q_Xa(1,1));
b_local = s_0*sqrt(Q_Xa(2,2));


% errror elipse for global coordinate

% for rotation angle

t = (1/2)*atan(Q_Xa(1,2)/(Q_Xa(2,2)-Q_Xa(1,1)));
R = [sin(t), cos(t); -cos(t), sin(t)];
Q = [Q_Xa(1,1),Q_Xa(1,2);
     Q_Xa(2,1),Q_Xa(2,2)];
Q_zz = R*Q*R';
a_global =  s_0*sqrt(Q_zz(1,1));
b_global =  s_0*sqrt(Q_zz(2,2));


% Plot Error ellipse

covariance_matrix = Q_Xa;  % Covariance matrix

% Number of points on the ellipse
num_points = 100;

% Generate points on the unit circle
theta = linspace(0, 2 * pi, num_points);
points_on_circle1= [a_global*cos(theta); b_global*sin(theta)];
points_on_circle2 = [a_local*cos(theta); b_local*sin(theta)];

% Plot the ellipse
figure(9);
plot(points_on_circle1(1, :), points_on_circle1(2, :), '-');
hold on;
plot(points_on_circle2(1, :), points_on_circle2(2, :), '-');
title('Error Ellipse Point A:Over Constraint');
xlabel('X-axis');
ylabel('Y-axis');
hold off;
grid on;
axis equal;
fprintf('------------------------------------------------------------------\n');

% errror elipse for local coordinate
s_0 = sqrt(apost);
a_local = s_0*sqrt(Q_Xa(3,3));
b_local = s_0*sqrt(Q_Xa(4,4));


% errror elipse for global coordinate

% for rotation angle

t = (1/2)*atan(Q_Xa(3,4)/(Q_Xa(4,4)-Q_Xa(3,3)));
R = [sin(t), cos(t); -cos(t), sin(t)];
Q = [Q_Xa(3,3),Q_Xa(3,4);
     Q_Xa(4,3),Q_Xa(4,4)];
Q_zz = R*Q*R';
a_global =  s_0*sqrt(Q_zz(1,1));
b_global =  s_0*sqrt(Q_zz(2,2));


% Plot Error ellipse

covariance_matrix = Q_Xa;  % Covariance matrix

% Number of points on the ellipse
num_points = 100;

% Generate points on the unit circle
theta = linspace(0, 2 * pi, num_points);
points_on_circle1= [a_global*cos(theta); b_global*sin(theta)];
points_on_circle2 = [a_local*cos(theta); b_local*sin(theta)];

% Plot the ellipse
figure(11);
plot(points_on_circle1(1, :), points_on_circle1(2, :), '-');
hold on;
plot(points_on_circle2(1, :), points_on_circle2(2, :), '-');
title('Error Ellipse Point B: Over constraint');
xlabel('X-axis');
ylabel('Y-axis');
hold off;
grid on;
axis equal;
fprintf('------------------------------------------------------------------\n');

% errror elipse for local coordinate
s_0 = sqrt(apost);
a_local = s_0*sqrt(Q_Xa(5,5));
b_local = s_0*sqrt(Q_Xa(6,6));


% errror elipse for global coordinate

% for rotation angle

t = (1/2)*atan(Q_Xa(5,6)/(Q_Xa(6,6)-Q_Xa(5,5)));
R = [sin(t), cos(t); -cos(t), sin(t)];
Q = [Q_Xa(5,5),Q_Xa(5,6);
     Q_Xa(5,6),Q_Xa(6,6)];
Q_zz = R*Q*R';
a_global =  s_0*sqrt(Q_zz(1,1));
b_global =  s_0*sqrt(Q_zz(2,2));


% Plot Error ellipse

covariance_matrix = Q_Xa;  % Covariance matrix

% Number of points on the ellipse
num_points = 100;

% Generate points on the unit circle
theta = linspace(0, 2 * pi, num_points);
points_on_circle1= [a_global*cos(theta); b_global*sin(theta)];
points_on_circle2 = [a_local*cos(theta); b_local*sin(theta)];

% Plot the ellipse
figure(12);
plot(points_on_circle1(1, :), points_on_circle1(2, :), '-');
hold on;
plot(points_on_circle2(1, :), points_on_circle2(2, :), '-');
title('Error Ellipse Point C : Over constraint');
xlabel('X-axis');
ylabel('Y-axis');
hold off;
grid on;
axis equal;
fprintf('------------------------------------------------------------------\n');

fprintf("Chi-Square Test: \n");

alph = 0.05;  % Significance level
DOF = s;
% Finding the critical value for a chi-square distribution
critical_value1 = chi2inv((alph/2),DOF);
critical_value2 = chi2inv((1 - (alph/2)),DOF);

Chi= VTPV/apost;

if Chi > critical_value1 && Chi < critical_value2
        fprintf("Chi-Square test succefully done \n");
    else
        fprintf("Chi-Square test fails \n");
end

%% Q1 E. Condition equation 
clear all
clc
% Given

c = 562.100 ; % in meter
a = 623.800 ;% in meter
b = 746.838 ;% in meter
A = (pi/180)*(dms2degrees(54,44,50)); % in radians
B = (pi/180)*(dms2degrees(77,52,10)); % in radians
C = (pi/180)*(dms2degrees(47,22,55)); % in radians

Lb = [c;a;b;A;B;C];
disp('Onservation Matrix Lb:');
disp(Lb);
fprintf('-------------------------------------------------------------\n');

% Error - covariances we have

e1 =  5/1000 ; % in mm
e2 =  5/1000 ;% in mm
e3 =  5/1000 ;% in mm
e4 = (pi/180)*dms2degrees(0,0,5);
e5 = (pi/180)*dms2degrees(0,0,5);
e6 = (pi/180)*dms2degrees(0,0,5);


 % sigma lblb
E_lb = diag([e1^2,e2^2,e3^2,e4^2,e5^2,e6^2]);
apriori = 1; % sigma_0 square
P = apriori * inv(E_lb);

disp(" Weight Matirx P:");
%disp(P);
fprintf('-------------------------------------------------------------\n');


% Number of observations
n = 6;
disp('Number of observation:');
disp(n);
% No. of Paramters
u = 6;
disp('Number of Parameters:');
disp(u);
% Degree f freedom
r = 4;
disp('Degree of Freedom:');
disp(r);
fprintf('-------------------------------------------------------------\n');

disp('Since Degree of Freedom is 0 so we apply constarints to solve them:');
fprintf('-------------------------------------------------------------\n');

% intial coordinates

ax_i = 1000.0 ; % in meters
ay_i = 1000.0 ; % in meters
bx_i = 1386.9 ; % in meters
by_i = 1407.3 ; % in meters
cx_i = 1739.1 ; % in meters
cy_i =  892.8 ; % in meters


X0 = [ax_i; ay_i; bx_i; by_i; cx_i; cy_i];
fprintf('Initial Coordinates Matrix X0 (Up to 3 decimal places):\n');
fprintf('%.3f\n', X0);

fprintf('-------------------------------------------------------------\n');
% intial coordinates

ax_i = 1000.0 ; % in meters
ay_i = 1000.0 ; % in meters
bx_i = 1386.9 ; % in meters
by_i = 1407.3 ; % in meters
cx_i = 1739.1 ; % in meters
cy_i =  892.8 ; % in meters


X0 = [ax_i; ay_i; bx_i; by_i; cx_i; cy_i];
fprintf('Initial Coordinates Matrix X0 (Up to 3 decimal places):\n');
fprintf('%.3f\n', X0);

fprintf('-------------------------------------------------------------\n');

VTPV = 0;
for i= 1:100

% Misclosure vector

syms a b c A B C

f1 = b*sin(A) - a*sin(B);
f2 = c*sin(B) - b*sin(C) ;
f3 = c*sin(A) - a*sin(C);
f4 = A + B + C - pi;

equ = [f1,f2,f3,f4]';
Wc = double(subs(equ,[c,a,b,A,B,C],Lb'));
disp('Misclosure Vector Wc:');
% disp(Wc);

fprintf('-------------------------------------------------------------\n');

% Preparing Design matrix A

parameter_1 = [c,a,b,A,B,C];
equations = [f1,f2,f3,f4]';

b1 = jacobian(equations, [c,a,b,A,B,C]);
B=double(subs(b1,[c,a,b,A,B,C],Lb'));

% Display the Jacobian matrix
disp("B: Design Matrix");
%disp(A);

M = B*inv(P)*B';
K = inv(M)*Wc;

V_linear = inv(P)*B'*K;
V = V_linear;

VTPV2 = V'*B'*K;

VTPV1 = V'*P*V;

 % Adjusted values of the observations
 La = Lb + V;


disp('Iteration no')
disp(i)
 if abs(VTPV1 -VTPV)< 10^(-8)
     disp('Convergence is achieved')
 % A posteriori varience
        sigma_aposteiori= VTPV1/(r) ;
        disp('A posteriori varience')
        disp(sigma_aposteiori)
     break
 else 
     % substitute the updated values
     L1 = La;
     VTPV = VTPV1;

 end
end

 disp('Adjusted Values of observations-');
 disp(La);
 La1 = La(1);
La2 = La(2);
La3 = La(3);
La4 = deg2dms((180/pi)*La(4));
La5 = deg2dms((180/pi)*La(5));
La6 = deg2dms((180/pi)*La(6));

fprintf('--------------------------------------------------------------\n');

disp("Adjusted Observation")
disp(La1);
disp(La2);
disp(La3);
disp(La4);
disp(La5);
disp(La6);
fprintf('--------------------------------------------------------------\n');

 disp("Residual Vector V:");
fprintf('%.12f\n',V_linear);
fprintf('--------------------------------------------------------------\n');
fprintf('--------------------------------------------------------------\n');
disp("Residual")
V01 = 1000*V_linear(1);
V02 = 1000*V_linear(2);
V03 = 1000*V_linear(3);
V04 = deg2dms((180/pi)*V_linear(4));
V05 = deg2dms((180/pi)*V_linear(5));
V06 = deg2dms((180/pi)*V_linear(6));

disp(V01);
disp(V02);
disp(V03);
disp(V04);
disp(V05);
disp(V06);
fprintf('--------------------------------------------------------------\n');

% Various Checks

  fprintf('------------------------Checks----------------------------\n');

% Stochastic Part 
disp('Stocastic Part')

 fprintf('--------------------------------------------------------------\n');

 % Computation of weighted coefficient matrix for observed Quantities
 Q_Lb = inv(P);
 disp('Weighted coefficient matrix for Observed Quantities (Q_Lb) (6 x 6)-');
 disp(Q_Lb);

fprintf('--------------------------------------------------------------\n');

 % Computation of weighted coefficient matrix for adjusted observation
Q_La = inv(P)-(inv(P)*B'*inv(M)*B*inv(P));
disp('Weighted Coefficient matrix for Adjusted Observation (Q_La)(6 x 6)');
 disp(Q_La);

 fprintf('--------------------------------------------------------------\n');

 % Computation of weighted coefficient matrix for residual
Q_V = Q_Lb - Q_La;
disp('Weighted Coefficient matrix for Residual (Q_V) (6 x 6)');
 disp(Q_V);

 fprintf('--------------------------------------------------------------\n');
apost = sigma_aposteiori;
 % Covariance matrix for Observed Values
 sigma_Lb = apost*Q_Lb;
 disp('Covariance Matrix of observation Q_Lb (6 x 6)-');
 disp(sigma_Lb);

fprintf('--------------------------------------------------------------\n');

 % A posteriori covariance matrix for adjusted observation
 sigma_La = apost*Q_La;
 disp('Covariance Matrix of Adjusted Values Q_La (6 x 6)-');
 disp(sigma_La);

fprintf('--------------------------------------------------------------\n');

 % A poesteriori covariance matrix for residuals
 sigma_V = apost*Q_V;
 disp('Covariance Matrix of Residual Q_v (6 x 6) ');
 disp(sigma_V);

 fprintf('--------------------------------------------------------------\n');

 % Post processing

% Pope's tau Test 

% tinv of machine learning toolbox used with 0.95 as confidence interval
% and r as degree of fredom

% Calculate the t-value for the 0.95 confidence interval and given degrees of freedom
t_v1 = tinv(0.95, r);

% Calculate the threshold for the test statistic
T_v = t_v1 * sqrt(r) / sqrt(r - 1 + t_v1^2);

% Assuming V is a vector, Test statistics
V = V;
for i = 1:length(V)
    % Assuming sigma_0_sqr is a predefined variable
    T_i = V(i) / apost * sqrt(Q_V(i, i));
    
    % Perform the test
    if T_i > T_v
        disp(['Hypothesis rejected for element ' num2str(i)]);
    else
        disp(['Hypothesis accepted for element ' num2str(i)]);
    end
end

 fprintf('--------------------------------------------------------------\n');
fprintf("Chi-Square Test: \n");

alph = 0.05;  % Significance level
DOF = r;
% Finding the critical value for a chi-square distribution
critical_value1 = chi2inv((alph/2),DOF);
critical_value2 = chi2inv((1 - (alph/2)),DOF);

Chi= VTPV/apost;

if Chi > critical_value1 && Chi < critical_value2
        fprintf("Chi-Square test succefully done \n");
    else
        fprintf("Chi-Square test fails \n");
end

 fprintf('--------------------------------------------------------------\n');