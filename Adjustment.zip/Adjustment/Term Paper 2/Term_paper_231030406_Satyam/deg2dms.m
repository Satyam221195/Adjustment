function dmsString = deg2dms(decimalDegrees)
    degrees = fix(decimalDegrees);
    remaining = (decimalDegrees - degrees) * 60;
    minutes = fix(remaining);
    seconds = (remaining - minutes) * 60;
    
    dmsString = [num2str(degrees) '° ' num2str(minutes) ''' ' num2str(seconds) '"'];
end
