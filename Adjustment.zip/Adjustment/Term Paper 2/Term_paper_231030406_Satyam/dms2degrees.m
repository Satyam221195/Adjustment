function decimalDegrees = dms2degrees(degrees, minutes, seconds)
    decimalDegrees = degrees + (minutes / 60) + (seconds / 3600);
end