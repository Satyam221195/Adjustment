clear all
clc
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
fprintf('---------------------------Term Paper-------------------------\n')
fprintf('-------Satyam Agnihotri----- Roll No. 231030406---------------\n')
fprintf('--------------------------------------------------------------\n');


%% For given condition we have 3 types of data fixed, observed and unknown

% A and B are observed
% Cordinated of C is fixed
% D and E are unknown

fprintf('--------------------------------------------------------------\n');

% fixed values
x_c = 1000;
y_c = 1000;

% Observation values

x_a = 792.882;
y_a = 1177.874;
x_b = 946.215;
y_b = 1094.514;
CD = 164.247 ; % in metres
BC = 108.367 ; % in metres
BD = 209.839 ; % in metres 
AB = 174.539 ; % in metres
AE = 214.181 ; % in metres
DE = 199.063 ; % in metres
a_EAB = deg2rad(dms2degrees([33,26,17.1])); % converted to radians
a_CDE = deg2rad(dms2degrees([64,08,16.6])); % converted to radians

% Obsvation Matrix Lb is
 
Lb = [x_a;y_a;x_b;y_b;CD;BC;BD;AB;AE;DE;a_EAB;a_CDE];
disp('Observation Matrix Lb:');
disp(Lb);

fprintf('--------------------------------------------------------------\n');

% Number of Equations
n = 12;
disp('Number of Equations:');
disp(n);
% No. of Paramters
u = 8;
disp('Number of Parameters:');
disp(u);
% Redundency
r = n -u;
disp('Number of Redundant Equations:');
disp(r);

fprintf('--------------------------------------------------------------\n');

% Matrix for given sigma lb lb


sigma_ab = [1.000,0.300,0.700,0.200;
            0.300,1.000,0.200,0.700;
            0.700,0.200,1.000,0.300;
            0.200,0.700,0.300,1.000]; % for the cordinates 
sigma_distance = diag([0.030^2,0.030^2,0.030^2,0.020^2,0.060^2,0.060^2,(2/206265)^2,(2/206265)^2]);

% 12x12 matrix with zeros so that we can merge our sigma valuess
sigma_lblb = zeros(12);

% 1st 4x4 matrix of the sigma_ab
sigma_lblb(1:4, 1:4) = sigma_ab;
% 2nd ater 4th row and column 8x8 block with the sigma_distance matrix
sigma_lblb(5:12, 5:12) = sigma_distance;
disp('Variance-Covariance matrix of observations ')
disp(sigma_lblb)
fprintf('\n')

fprintf('--------------------------------------------------------------\n');

% evaluation of the weight matrix P

P = inv(sigma_lblb);
disp('Weight Matrix P:');
disp(P)

fprintf('---------------------------------------------------------------\n');

% Before proceeding to the design matrix A our observation equation is
% non-linear type so intial values will be required

% For initial values considering the 2 eqations and solving them

syms x_d y_d

% Define the equations to find initial values of X and Y as X_o and Y_o
eq_1 = (x_d - x_b)^2 + (y_d - y_b)^2 == BD^2;
eq_2 = (x_d - x_c)^2 + (y_d - y_c)^2 == CD^2;

% calculation for cordinates of D
coordinates_D = solve([eq_1, eq_2], [x_d, y_d]);

% coordinated of point D
x_D = coordinates_D.x_d;
y_D = coordinates_D.y_d;
disp('Coordinates:\n');
for i = 1:length(x_d)
    fprintf('x_d = %.2f, y_d = %.2f\n', double(x_D(i)), double(y_D(i)))
end
fprintf('--------------------------------------------------------------\n');
% we get two values fo x_d and y_d and opting 1 values as intial value
x_d_initial = double(x_D(2));
y_d_initial = double(y_D(2));

fprintf('Initial values of D coordinates are:\n X D = %d\n Y D = %d\n',x_d_initial,y_d_initial);
fprintf('-------------------------------------------------------------\n');

syms x_e y_e

% Define the equations to find initial values of X and Y as X_o and Y_o
eq_3 = (x_e - x_a)^2 + (y_e - y_a)^2 == AE^2;
eq_4 = (x_e - x_d_initial)^2 + (y_e - y_d_initial)^2 == DE^2;

% calculation for cordinates of E
coordinates_E = solve([eq_3, eq_4], [x_e, y_e]);

% coordinated of point D
x_E = coordinates_E.x_e;
y_E = coordinates_E.y_e;
disp('Coordinates:');
for i = 1:length(x_e)
    fprintf('x_e = %.2f, y_e = %.2f\n', double(x_E(i)), double(y_E(i)))
end

fprintf('--------------------------------------------------------------\n');

% we get two values fo x_d and y_d and opting 1 values as intial value
x_e_initial = double(x_E(2));
y_e_initial = double(y_E(2));
fprintf('Initial values of E coordinates are:\n X E = %d\n Y E = %d\n',x_e_initial,y_e_initial);

fprintf('--------------------------------------------------------------\n');

% parameteric matrix in its initial phase for computation

X_initial = [x_a;y_a;x_b;y_b;x_e_initial;y_e_initial;x_d_initial;y_d_initial];


% for the purpose of iteration required in solutiion, prepared a loop for
% continuosly caclcuting until the convergence have been achived for
% VTPV_linear - VTPV_non linear till our convergence tolreance have been
% achived

for i =1:100

% initial estimate Lb by [f(x_initial,y_initial)=L_initial]

Lb_1 = X_initial(1);
Lb_2 = X_initial(2);
Lb_3 = X_initial(3);
Lb_4 = X_initial(4);
Lb_5=sqrt(((X_initial(7)-x_c)^2)+((X_initial(8)-y_c)^2));
Lb_6=sqrt(((X_initial(3)-x_c)^2)+((X_initial(4)-y_c)^2));
Lb_7=sqrt(((X_initial(3)-X_initial(7))^2)+((X_initial(4)-X_initial(8))^2));
Lb_8=sqrt(((X_initial(3)-X_initial(1))^2)+((X_initial(4)-X_initial(2))^2));
Lb_9=sqrt(((X_initial(5)-X_initial(1))^2)+((X_initial(6)-X_initial(2))^2));
Lb_10=sqrt(((X_initial(5)-X_initial(7))^2)+((X_initial(6)-X_initial(8))^2));
Lb_11=atan((X_initial(3)-X_initial(1))/(X_initial(4)-X_initial(2)))-atan((X_initial(5)-X_initial(1))/(X_initial(6)-X_initial(2)))+pi;
Lb_12=-atan((x_c-X_initial(7))/(y_c-X_initial(8)))+atan((X_initial(5)-X_initial(7))/(X_initial(6)-X_initial(8)))+pi;

L_initial = [Lb_1;Lb_2;Lb_3;Lb_4;Lb_5;Lb_6;Lb_7;Lb_8;Lb_9;Lb_10;Lb_11;Lb_12];

% calculating value of L = raw observations(L_b) - initial observations(L_initial)
L = Lb - L_initial ;


% the design matrix 'A'
% defining symbolic variablers
 syms Xa Ya Xb Yb Xe Ye Xd Yd

% functions of equation

 f1 = Xa - Lb(1);
 f2 = Ya - Lb(2);
 f3 = Xb - Lb(3);
 f4 = Yb - Lb(4);
 f5 = sqrt(( Xd - x_c)^2+ (Yd - y_c)^2) - Lb(5);
 f6 = sqrt((x_c-Xb)^2+(y_c - Yb)^2)-Lb(6);
 f7 = sqrt((Xd - Xb)^2 + (Yd - Yb)^2) - Lb(7);
 f8 = sqrt((Xb - Xa)^2 + (Yb - Ya)^2) - Lb(8);
 f9 = sqrt((Xe - Xa)^2 + (Ye - Ya)^2) - Lb(9);
 f10 = sqrt((Xe - Xd)^2 + (Ye - Yd)^2) - Lb(10);
 f11 = atan((Xb - Xa)/(Yb - Ya)) - atan((Xe - Xa)/(Ye - Ya)) - Lb(11)  +pi;
 f12 = atan((Xe - Xd)/(Ye-Yd)) - atan((x_c- Xd)/(y_c-Yd)) - Lb(12) + pi;

 functions = [f1;f2;f3;f4;f5;f6;f7;f8;f9;f10;f11;f12];
 % storing the parameters in matrix format with whom we have to
 % take jacobian (partial derivative)
parameters = [Xa Ya Xb Yb  Xe Ye Xd Yd];

% finding jacobian for each function and using subs to substitute the
% values
A=[];

j = jacobian(functions,parameters);
J_subs = subs(j,[Xa Ya Xb Yb  Xe Ye Xd Yd],[X_initial(1), X_initial(2),X_initial(3), X_initial(4),X_initial(5), X_initial(6),X_initial(7), X_initial(8)]);
A = [A;J_subs];

A = double (A);

% Computtion of N
% Computing the normal equation to find parameters
% normal equation form NX-U = 0 ; X = inv(N)*U
% N= ATPA
N= A'*P*A ;

 % Computation of U
 U = (A'*P*L);

 % Computation of N inverse
 N_inv = inv(N);

% Computation of X parametric matrix 
 X = (N_inv*U);

% Computing linear residual (V_linear)
V_linear = A * X - L ;

%computing linear residual using VTPV linear
VTPV_linear = V_linear'*P*V_linear;

% updating value of X
X_hat = X_initial+ X;

% Compute adjusted observations
La =  V_linear + Lb;

% computing non linear residual V nonlinear

l_1 = X_hat(1)-Lb(1);
l_2 = X_hat(2)-Lb(2);
l_3 = X_hat(3)-Lb(3);
l_4 = X_hat(4)-Lb(4);
l_5 = sqrt(((X_hat(7)-x_c)^2)+((X_hat(8)-y_c)^2))-Lb(5);
l_6 = sqrt(((X_hat(3)-x_c)^2)+((X_hat(4)-y_c)^2))-Lb(6);
l_7 = sqrt(((X_hat(3)-X_hat(7))^2)+((X_hat(4)-X_hat(8))^2))-Lb(7);
l_8 = sqrt(((X_hat(3)-X_hat(1))^2)+((X_hat(4)-X_hat(2))^2))-Lb(8);
l_9 = sqrt(((X_hat(5)-X_hat(1))^2)+((X_hat(6)-X_hat(2))^2))-Lb(9);
l_10 = sqrt(((X_hat(5)-X_hat(7))^2)+((X_hat(6)-X_hat(8))^2))-Lb(10);
l_11 = atan((X_hat(3)-X_hat(1))/(X_hat(4)-X_hat(2)))-atan((X_hat(5)-X_hat(1))/(X_hat(6)-X_hat(2)))+pi-Lb(11);
l_12 = +atan((X_hat(5)-X_hat(7))/(X_hat(6)-X_hat(8)))-atan((x_c-X_hat(7))/(y_c-X_hat(8)))+pi-Lb(12);

l = [l_1;l_2;l_3;l_4;l_5;l_6;l_7;l_8;l_9;l_10;l_11;l_12];

V_nonlinear = l;

% Computing  VTPV nonlinear
VTPV_nonlinear =  V_nonlinear'*P*V_nonlinear;
tolerance = 10^-8;

fprintf('--------------------------------------------------------------\n');

disp('Iteration no')
disp(i)

fprintf('--------------------------------------------------------------\n');

%convergence based on |VTPV_nonlinear - VTPV_linear| < tolerance
    if abs(VTPV_nonlinear - VTPV_linear) <tolerance;
                
        % A posteriori varience
        sigma_aposteiori= VTPV_linear/(n-u) ;
        disp('A posteriori varience')
        disp(sigma_aposteiori)
        disp('Convergence criteria reached')
        fprintf('\n')
        break
    else
        %  adjusted parameters become approximate parameters
         X_initial = X_hat;
        % adjusted observation become approximate observations
         L_initial = La;
        
    end
end
fprintf('--------------------------------------------------------------\n');
 
disp('Adjusted Values of Parameters');
disp(La)

fprintf('--------------------------------------------------------------\n');

%% Stochastic Part 

 fprintf('--------------------------------------------------------------\n');

 % Computation of weighted coefficient matrix for observed Quantities
 Q_Lb = inv(P);
 disp('Weighted coefficient matrix for Observed Quantities (Q_Lb)-');
 disp(Q_Lb);

fprintf('--------------------------------------------------------------\n');

 %Computation of weighted coefficient matrix for observed Quantities
 Q_Xa = inv(N);
 disp('Weighted Coefficient matrix for Adjusted Parameters (Q_Xa)');
 disp(Q_Xa);

 fprintf('--------------------------------------------------------------\n');

 % Computation of weighted coefficient matrix for adjusted observation
Q_La = A*inv(n)*A';
disp('Weighted Coefficient matrix for Adjusted Observation (Q_La)');
 disp(Q_La);

 fprintf('--------------------------------------------------------------\n');

 % Computation of weighted coefficient matrix for residual
Q_V = Q_Lb - Q_La;
disp('Weighted Coefficient matrix for Residual (Q_V)');
 disp(Q_V);

 fprintf('--------------------------------------------------------------\n');

 % Covariance matrix for Observed Values
 sigma_Lb = sigma_aposteiori*Q_Lb;
 disp('Covariance Matrix of observation Q_Lb (12 x 12)-');
 disp(sigma_Lb);

 fprintf('--------------------------------------------------------------\n');

 % A posteriori covariance matrix for parameters
 sigma_Xa = sigma_aposteiori*Q_Xa;
 disp('Covariance Matrix of Parameters Q_Xa(8 x 8)-');
 disp(sigma_Xa);

fprintf('--------------------------------------------------------------\n');

 % A posteriori covariance matrix for adjusted observation
 sigma_La = sigma_aposteiori*Q_La;
 disp('Covariance Matrix of Adjusted Values Q_La (12 x 12)-');
 disp(sigma_La);

fprintf('--------------------------------------------------------------\n');

 % A poesteriori covariance matrix for residuals
 sigma_V = sigma_aposteiori*Q_V;
 disp('Covariance Matrix of Residual Q_v (12 x 12) ');
 disp(sigma_V);

 fprintf('--------------------------------------------------------------\n');

  %% Various Checks

  fprintf('------------------------Checks----------------------------\n');

% Check 1 for A'PV = 0

ATPV= A'*P*V_linear;
if ATPV < 10^-8
    fprintf('Then ATPV is 0 and check successful\n')
else 
    fprintf('Unsuccessful: ATPV is not zero')
end

fprintf('--------------------------------------------------------------\n');

% Check 2 Calculating V'PV by three methods
fprintf("\nCalculating V'PV by three methods:\n");
fprintf("V'PV = ")
VTPV= V_linear'*P*V_linear;
disp(double(VTPV));

fprintf('--------------------------------------------------------------\n');

fprintf("-V'PLb = ")
VTPL=-V_linear'*P*L;
disp(double(VTPL));

fprintf('--------------------------------------------------------------\n');

fprintf("-Lb'PV = ");
LTPV=-L'*P*V_linear;
disp(double(LTPV));

fprintf('--------------------------------------------------------------\n\n\n');

fprintf("\nCheck 3 : Normal Matrix\n");
Normal_Matrix = A'*P*A;
disp(double(Normal_Matrix));

fprintf('--------------------------------------------------------------\n');
